@echo off
title Claude Code Desktop
setlocal enabledelayedexpansion
cd /d "%~dp0"

:menu
cls
echo ============================================
echo   Claude Code Desktop
echo ============================================
echo.

:: Check Node.js
where node >nul 2>&1
if %errorlevel% neq 0 (
    echo [✗] Node.js 未安装
    echo     请从 https://nodejs.org 下载安装
    pause
    exit /b 1
)

:: Version info
for /f "tokens=*" %%v in ('node -e "try{console.log(require('%~dp0node_modules/@anthropic-ai/claude-code/package.json').version)}catch(e){console.log('未安装')}" 2^>nul') do set VER=%%v
echo   Claude Code: v%VER%
echo.
echo   [1] 启动 Claude Code
echo   [2] 安装 / 更新 Claude Code
echo   [3] 检查最新版本
echo   [4] 退出
echo.
set /p c="请选择 (1-4): "

if "%c%"=="1" goto launch
if "%c%"=="2" goto install
if "%c%"=="3" goto checkver
if "%c%"=="4" exit /b 0
goto menu

:launch
if not exist "%~dp0node_modules\@anthropic-ai\claude-code\cli-wrapper.cjs" (
    echo Claude Code 尚未安装，正在安装...
    goto install
)
cls
echo 启动中...
call claude
goto menu

:install
cls
echo 正在安装/更新 Claude Code（约100MB，仅首次）...
echo.
call npm install -g @anthropic-ai/claude-code@latest
echo.
if %errorlevel% equ 0 (
    echo ✅ 安装成功！
) else (
    echo ❌ 安装失败，请检查网络
)
pause
goto menu

:checkver
cls
echo 正在检查...
node -e "fetch('https://registry.npmjs.org/@anthropic-ai/claude-code/latest').then(r=>r.json()).then(d=>{console.log('最新版: '+d.version);try{var c=require('%~dp0node_modules/@anthropic-ai/claude-code/package.json').version;console.log('当前版: '+c);console.log(c!==d.version?'\n🔔 有新版本，选[2]更新':'✅ 已是最新')}catch(e){console.log('当前版: 未安装 → 选[2]安装')}}).catch(e=>console.log('检查失败: '+e.message))" 2>nul
pause
goto menu
